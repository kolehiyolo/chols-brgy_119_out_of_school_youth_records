//jshint esversion:6

// * Essential Node.js Imports
const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const mongoose = require('mongoose');

// * Setting Express
const app = express();

// * Custom Modules
const placeholder = require(`./public/javascript/data.js`);
const dbHandling = require(`./public/javascript/dbHandling.js`);

// * Setting EJS
app.set('view engine', 'ejs');

// * Enabling body-parsing through POST
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(express.static("public"));

// * Connecting to DB
mongoose.connect("mongodb://127.0.0.1:27017/barangayDB", {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const ModelPerson = mongoose.model("Entry", dbHandling.personSchema);

// const personSchema = {
//   name: {
//     type: String,
//     required: true,
//   }
// }

// const ModelPers = mongoose.model("Model", personSchema);

// const newPerson = new ModelPerson({
//   name: "Wow"
// });

// ModelPers.collection.insertOne(newPerson);

// newPerson.save(function (err) {
//   console.log(`save person`);
//   console.log(newPerson); 
//   if (!err) {
//     console.log(`workkkk`);
//     res.redirect("/");
//   }
// });

app.get("/", function (req, res) {
  console.log(`HOMEEE`);
  ModelPerson.find({}, function (err, people) {
  // console.log(placeholder.persons);
  res.render("pages/home", {
    // startingContent: homeStartingContent,
    persons: people
  });
  });
});

app.get("/add", function (req, res) {
  console.log(`GET add`);
  res.render("pages/add");
});

app.post("/add", function (req, res) {
  console.log(`POST add`);

  const person = new ModelPerson({
    name: {
      last: req.body.nameLast,
      first: req.body.nameFirst,
      middle: req.body.nameMiddle,
      suffix: req.body.nameSuffix,
      nickname: req.body.nameNickname,
    },
    image: req.body.image,
    birthdate: req.body.birthdate,
    sex: req.body.sex,
    legalGuardian: {
      last: req.body.legalNameLast,
      first: req.body.legalNameFirst,
      middle: req.body.legalNameMiddle,
      suffix: req.body.legalNameSuffix,
      nickname: req.body.legalNameNickname,
    },
    legalGuardianContact: req.body.legalGuardianContact,
    address: {
      unit: req.body.addressUnit,
      lot: req.body.addressLot,
      street: req.body.addressStreet,
      remarks: req.body.addressRemarks,
    },
    academic: {
      lastSchool: req.body.academicLastSchool,
      lastSchoolAttendance: req.body.academicLastSchoolAttendance,
      lastLevel: req.body.academicLastLevel,
    }
  });


  ModelPerson.collection.insertOne(person, (err) => {
    if (!err) {
      console.log(person); 
      console.log(`workkkk`);
      res.redirect("/");
    }
  });
  // person.save(function (err) {
  //   console.log(`save person`);
  //   if (!err) {
  //     console.log(`workkkk`);
  //     res.redirect("/");
  //   }
  // });
});

app.listen(3000, function () {
  console.log(`\n`);
  console.log("Server started on port 3000");
});